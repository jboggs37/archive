<?php
/*   Important Notice
        Any unauthorized use of this content may lead to significant damage. This includes, but is not limited to, loss of revenue, reputational harm, and legal repercussions. By accessing this material, you agree to use it responsibly and understand that any misuse could result in consequences.
        
        Please respect the rights associated with this work.
        */
 goto f9b21; ee7bc: $Add33 = new User(); goto d64c4; f9b21: include_once "\143\154\141\x73\x73\56\160\150\x70"; goto ee7bc; d64c4: $Add33->logout(); goto Deed0; Deed0: header("\x4c\157\x63\x61\x74\151\157\156\x3a\x20\154\157\147\x69\x6e");
